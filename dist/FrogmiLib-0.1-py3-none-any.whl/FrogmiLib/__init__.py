#from .funciones import getToken

def OSVersion():
    det = """Version 2.2 =============
    Libreria para agilizar el uso de las api de frogmi 5.1.2025
    USO:
    Consultar con John Arteaga!!!
    
    Nota importante _____
    Para modificar las columnas que se retornan, se debe editar el archivo funciones.py
    agregar las columnas en la funcion correspondiente y volver a compilar el archivo WHL:

    --> python .\setup.py bdist_wheel

    Publicar en GITHUB para obtener la version linux del archivo WHL y cagar en el Lakehouse
    """

    
    return det

