# Importamos las funciones de 'funciones.py' 
from .funciones import (
    getStores,
    getAreas,
    getUsers,
    getProducts,
    getTags,
    getResults,
    getEvents,
    getActivites,
    help
)